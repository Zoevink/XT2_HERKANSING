//mapbox api
mapboxgl.accessToken = 'pk.eyJ1IjoiZmVybHVjaTIiLCJhIjoiY2tvazkyaXptMDM5ZTJwcm1sZW1lcGxoNyJ9.fJvwUDAUZ6zpISneIJ1GgQ';
var map = new mapboxgl.Map({
    container: 'map', style: 'mapbox://styles/mapbox/streets-v11', center: [5, 52], zoom: 9});

var lat;
var lon;

// Locatie zoeken
var searchLocation = new MapboxGeocoder({ 
    accessToken: mapboxgl.accessToken,
    mapboxgl: mapboxgl,
    getItemValue: e => {
        lon = e['center'][0];
        lat = e['center'][1];
        document.getElementsByClassName('mapboxgl-ctrl-geocoder--input').value = e['place_name']; 
        return e['place_name'];
    }
});
document.getElementById('search').appendChild(searchLocation.onAdd(map));//zoekbalk

//Condities weer
var token = '108beef1e46b455a9a05ae9588c45b57'; //Persoonlijke token key
var temp = document.getElementById('showTemp');
var weather = document.getElementById('weather');
var showSafety = document.getElementById('showSafety');

weather.src = 'img/error.png'
function showWeatherCode(){
	fetch('https://api.weatherbit.io/v2.0/current?lat=' + lat + '&lon=' + lon + '&key=' + token + '&include=minutely')//  gekozen locatie wordt opgehaald
	.then(res=> res.json())

	.then(data => {
		temp.innerHTML = data['data'][0].temp + ' Celcius';//Temperatuur wordt uit de string response gehaald
		var code = data['data'][0].weather.code;// content van de weer code wordt uit de string opgehaald
		switch(true){
			case code >= 200 && code <=233:
				weather.src = 'img/thunder.png';
				showSafety.innerHTML = 'Het Onweert!';
			break;
			case code >= 300 && code <=522:
				weather.src = 'img/rain.png';
				showSafety.innerHTML = 'Het regent!';
			break;
			case code >= 600 && code <=623:
				weather.src = 'img/snow.png';
				showSafety.innerHTML = 'Het sneeuwt!';
			break;
			case code >= 700 && code <=751:
				weather.src = 'img/fog.png';
				showSafety.innerHTML = 'Het is mistig!';
			break;
			case code == 800 || code == 801:
				weather.src = 'img/sun.png';
				showSafety.innerHTML = 'De zon schijnt!';
			break;
			case code >= 802 && code <=804:
				weather.src = 'img/fog.png';
				showSafety.innerHTML = 'Het is mistig!';
			break;
			default:// Buiten de functie geschreven, omdat de png niet wordt weergegeven
			weather.src = 'img/error.png';
			break;
		}
	})
.catch(err => temp.innerHTML = ' - °C')
}

showWeatherCode()
setInterval(showWeatherCode, 1500);//de code outut werkt niet zonder interval